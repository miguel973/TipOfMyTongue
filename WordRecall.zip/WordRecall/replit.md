# Tip Of My Tongue - Word Suggestion App

## Overview

This is a full-stack TypeScript application that helps users find words they can't quite remember based on their descriptions. Users describe what they're thinking of, and the app uses OpenAI's GPT-4o model to suggest relevant words with definitions, categories, and match percentages.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

The application follows a modern full-stack architecture with:

- **Frontend**: React with TypeScript using Vite as the build tool
- **Backend**: Express.js server with TypeScript
- **Database**: PostgreSQL with Drizzle ORM (configured but not actively used in current implementation)
- **AI Integration**: OpenAI GPT-4o for intelligent word suggestions
- **UI Framework**: Tailwind CSS with shadcn/ui components
- **State Management**: TanStack Query for server state management

## Key Components

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite with hot module replacement
- **Routing**: Wouter for lightweight client-side routing
- **Styling**: Tailwind CSS with custom design tokens
- **UI Components**: shadcn/ui component library with Radix UI primitives
- **State Management**: TanStack React Query for API state
- **Voice Input**: Web Speech Recognition API integration

### Backend Architecture
- **Server**: Express.js with TypeScript
- **API Design**: RESTful endpoints with structured JSON responses
- **Validation**: Zod schemas for request/response validation
- **Error Handling**: Centralized error middleware
- **Logging**: Custom request/response logging middleware
- **Performance**: 1.2-second timeout enforcement for AI requests

### Data Layer
- **ORM**: Drizzle ORM configured for PostgreSQL
- **Database**: Neon serverless PostgreSQL (configured but minimal usage)
- **Storage**: In-memory storage for search analytics
- **Schema**: Shared TypeScript types between frontend and backend

## Data Flow

1. **User Input**: Users enter descriptions via text input or voice recognition
2. **Request Processing**: Frontend validates input using Zod schemas
3. **API Call**: POST request to `/api/search` with description and optional maxResults
4. **AI Processing**: Backend calls OpenAI GPT-4o with structured prompts
5. **Response Processing**: AI response parsed and validated against schemas
6. **Result Display**: Frontend renders word suggestions with match percentages
7. **Analytics**: Basic search logging for potential future features

## External Dependencies

### Core Dependencies
- **OpenAI API**: GPT-4o model for intelligent word suggestions
- **Neon Database**: Serverless PostgreSQL hosting
- **Radix UI**: Headless UI components for accessibility
- **TanStack Query**: Server state management and caching

### Development Tools
- **Vite**: Fast development server and build tool
- **TypeScript**: Type safety across the entire stack
- **Tailwind CSS**: Utility-first CSS framework
- **Drizzle Kit**: Database migrations and schema management

### Optional Features
- **Voice Input**: Web Speech Recognition API (browser-dependent)
- **Replit Integration**: Development environment optimizations

## Deployment Strategy

### Development
- **Dev Server**: Vite development server with Express API proxy
- **Hot Reload**: Real-time code changes without full page refresh
- **Environment**: NODE_ENV=development with debug logging

### Production Build
- **Frontend**: Vite builds React app to `dist/public`
- **Backend**: esbuild bundles Express server to `dist/index.js`
- **Static Serving**: Express serves built frontend assets
- **Environment**: NODE_ENV=production with optimized logging

### Environment Variables
- `DATABASE_URL`: PostgreSQL connection string (Neon)
- `OPENAI_API_KEY`: OpenAI API authentication
- `NODE_ENV`: Environment flag (development/production)

### Architecture Decisions

**Problem**: Need fast, intelligent word suggestions based on user descriptions
**Solution**: Multi-provider AI system with OpenAI, Anthropic, and Gemini support
**Rationale**: Provides human-like understanding of vague descriptions with user choice of AI models

**Problem**: Prevent API budget attacks and give users control over costs
**Solution**: User-provided API keys with secure local storage + fallback server key
**Rationale**: Users control their own AI costs while maintaining demo functionality

**Problem**: Ensure responsive user experience with AI latency
**Solution**: 10-second timeout with optimized prompts and faster models
**Rationale**: Balances AI processing time with user experience expectations

**Problem**: Maintain type safety across frontend and backend
**Solution**: Shared TypeScript schemas using Zod
**Rationale**: Single source of truth for data validation and type definitions

**Problem**: Provide accessible, modern UI components
**Solution**: shadcn/ui built on Radix UI primitives
**Rationale**: Combines accessibility best practices with customizable styling

### Recent Changes (July 28, 2025)

**Major Update**: Multi-Provider AI System
- Added support for OpenAI, Anthropic (Claude), and Google Gemini
- Implemented user-provided API key system with secure local storage
- Created API settings dialog with provider/model selection
- API keys stored locally in browser, never sent to our servers
- Fallback to server's OpenAI key for demo usage
- Budget protection: users pay for their own AI usage

**Latest Update**: Subdomain Deployment Ready
- Built comprehensive About page with technical documentation
- Deployed app on Replit for subdomain hosting
- Created DNS setup guide for words.taverasholdings.com
- Zero-cost hosting solution with professional custom domain
- Ready for 5-minute DNS configuration to go live