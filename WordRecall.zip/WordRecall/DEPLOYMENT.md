# Tip Of My Tongue - Deployment Guide

## Overview
This guide will help you integrate the Tip Of My Tongue app into your main website at `taverasholdings.com/tomt` (or `/tipofmytongue` or `/llmgame`).

## Recommended Path
**`taverasholdings.com/tomt`** - Short, memorable, and professional

## Files to Deploy
After running `npm run build`, you'll have:
- `dist/public/` - Contains all frontend assets (HTML, CSS, JS)
- `dist/index.js` - Backend server file
- `package.json` - Dependencies

## Integration Options

### Option 1: Standalone Microservice (Recommended)
Deploy this as a separate service and use a reverse proxy:

**Nginx Configuration:**
```nginx
location /tomt/ {
    proxy_pass http://localhost:5000/;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
}
```

### Option 2: Static Files + API Proxy
1. Copy `dist/public/*` to your web server at `/tomt/`
2. Set up API proxy for `/tomt/api/*` to point to the backend service

### Option 3: Full Integration
Integrate into your existing Node.js/Express application:
1. Copy the built frontend files to your static assets
2. Import the API routes into your main Express app

## Environment Variables Needed
```bash
OPENAI_API_KEY=your_openai_key_here
DATABASE_URL=postgresql://... (optional, for future features)
NODE_ENV=production
```

## Backend API Endpoints
- `POST /api/search` - Main word search functionality
- Expects JSON: `{"description": "word description", "maxResults": 5}`

## Frontend Configuration
The app is built as a SPA that expects:
- API endpoints at `/api/*` relative to the deployment path
- All static assets served from the same domain/path

## Dependencies
Key production dependencies:
- `express` - Web server
- `@anthropic-ai/sdk` - Anthropic Claude API
- `@google/genai` - Google Gemini API  
- `openai` - OpenAI API
- `zod` - Data validation

## Security Notes
- API keys are handled securely (user-provided keys stored in browser localStorage)
- Server has fallback OpenAI key for demo functionality
- No sensitive data stored permanently
- Request timeouts prevent runaway API costs

## Performance
- Typical response times: 750ms - 1.5s
- Frontend optimized for fast loading
- Efficient bundle splitting and caching

## Testing the Integration
1. Verify `/tomt/` loads the main interface
2. Test word search functionality
3. Check voice input (browser-dependent)
4. Verify API settings dialog works
5. Test both with and without user API keys

## Support
- Built with React + TypeScript frontend
- Express.js backend with multi-provider AI integration
- Full source code available in this Replit project