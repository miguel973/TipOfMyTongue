import { z } from "zod";

export const wordSuggestionSchema = z.object({
  word: z.string(),
  definition: z.string(),
  category: z.string(),
  matchPercentage: z.number().min(0).max(100),
  etymology: z.string().optional(),
  examples: z.array(z.string()).optional()
});

export const searchRequestSchema = z.object({
  description: z.string().min(1, "Description cannot be empty"),
  maxResults: z.number().min(1).max(10).default(5),
  provider: z.string().optional(),
  model: z.string().optional(),
  apiKey: z.string().optional()
});

export const searchResponseSchema = z.object({
  suggestions: z.array(wordSuggestionSchema),
  processingTimeMs: z.number(),
  hasMore: z.boolean()
});

export type WordSuggestion = z.infer<typeof wordSuggestionSchema>;
export type SearchRequest = z.infer<typeof searchRequestSchema>;
export type SearchResponse = z.infer<typeof searchResponseSchema>;
