import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Settings, Eye, EyeOff } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export interface ApiProvider {
  id: string;
  name: string;
  models: string[];
  keyPlaceholder: string;
  instructions: string;
}

export const API_PROVIDERS: ApiProvider[] = [
  {
    id: 'openai',
    name: 'OpenAI',
    models: ['gpt-4o', 'gpt-4o-mini', 'gpt-3.5-turbo'],
    keyPlaceholder: 'sk-...',
    instructions: 'Get your API key from https://platform.openai.com/api-keys'
  },
  {
    id: 'anthropic',
    name: 'Anthropic (Claude)',
    models: ['claude-sonnet-4-20250514', 'claude-3-7-sonnet-20250219'],
    keyPlaceholder: 'sk-ant-...',
    instructions: 'Get your API key from https://console.anthropic.com'
  },
  {
    id: 'gemini',
    name: 'Google Gemini',
    models: ['gemini-2.5-flash', 'gemini-2.5-pro'],
    keyPlaceholder: 'AI...',
    instructions: 'Get your API key from https://aistudio.google.com/app/apikey'
  }
];

interface ApiConfig {
  provider: string;
  model: string;
  apiKey: string;
}

interface ApiSettingsProps {
  onConfigChange: (config: ApiConfig) => void;
}

export function ApiSettings({ onConfigChange }: ApiSettingsProps) {
  const [open, setOpen] = useState(false);
  const [showKey, setShowKey] = useState(false);
  const { toast } = useToast();

  // Load saved config from localStorage
  const loadConfig = (): ApiConfig => {
    try {
      const saved = localStorage.getItem('tip-of-tongue-api-config');
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (error) {
      console.error('Error loading API config:', error);
    }
    
    return {
      provider: 'openai',
      model: 'gpt-4o-mini',
      apiKey: ''
    };
  };

  const [config, setConfig] = useState<ApiConfig>(loadConfig);
  const selectedProvider = API_PROVIDERS.find(p => p.id === config.provider);

  const saveConfig = (newConfig: ApiConfig) => {
    try {
      localStorage.setItem('tip-of-tongue-api-config', JSON.stringify(newConfig));
      setConfig(newConfig);
      onConfigChange(newConfig);
      toast({
        title: "Settings saved",
        description: `Using ${selectedProvider?.name} with ${newConfig.model}`,
      });
    } catch (error) {
      toast({
        title: "Error saving settings",
        description: "Unable to save API configuration",
        variant: "destructive",
      });
    }
  };

  const handleProviderChange = (providerId: string) => {
    const provider = API_PROVIDERS.find(p => p.id === providerId);
    if (provider) {
      const newConfig = {
        ...config,
        provider: providerId,
        model: provider.models[0] // Default to first model
      };
      saveConfig(newConfig);
    }
  };

  const handleModelChange = (model: string) => {
    const newConfig = { ...config, model };
    saveConfig(newConfig);
  };

  const handleApiKeyChange = (apiKey: string) => {
    const newConfig = { ...config, apiKey };
    saveConfig(newConfig);
  };

  const hasValidConfig = config.apiKey.trim().length > 0;

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button 
          variant="ghost" 
          size="icon"
          className={`${hasValidConfig ? 'text-green-600' : 'text-gray-400'} hover:bg-gray-100`}
          title="API Settings"
        >
          <Settings className="h-4 w-4" />
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>AI Provider Settings</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          {/* Provider Selection */}
          <div className="space-y-2">
            <Label htmlFor="provider">AI Provider</Label>
            <Select value={config.provider} onValueChange={handleProviderChange}>
              <SelectTrigger>
                <SelectValue placeholder="Select provider" />
              </SelectTrigger>
              <SelectContent>
                {API_PROVIDERS.map(provider => (
                  <SelectItem key={provider.id} value={provider.id}>
                    {provider.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Model Selection */}
          {selectedProvider && (
            <div className="space-y-2">
              <Label htmlFor="model">Model</Label>
              <Select value={config.model} onValueChange={handleModelChange}>
                <SelectTrigger>
                  <SelectValue placeholder="Select model" />
                </SelectTrigger>
                <SelectContent>
                  {selectedProvider.models.map(model => (
                    <SelectItem key={model} value={model}>
                      {model}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          {/* API Key Input */}
          <div className="space-y-2">
            <Label htmlFor="apiKey">API Key</Label>
            <div className="relative">
              <Input
                id="apiKey"
                type={showKey ? "text" : "password"}
                placeholder={selectedProvider?.keyPlaceholder || "Enter API key"}
                value={config.apiKey}
                onChange={(e) => handleApiKeyChange(e.target.value)}
                className="pr-10"
              />
              <Button
                type="button"
                variant="ghost"
                size="icon"
                className="absolute right-0 top-0 h-full px-3 hover:bg-transparent"
                onClick={() => setShowKey(!showKey)}
              >
                {showKey ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </Button>
            </div>
          </div>

          {/* Instructions */}
          {selectedProvider && (
            <div className="text-sm text-gray-600 bg-gray-50 p-3 rounded">
              <p className="font-medium mb-1">How to get your API key:</p>
              <p>{selectedProvider.instructions}</p>
            </div>
          )}

          {/* Privacy Notice */}
          <div className="text-xs text-gray-500 bg-blue-50 p-2 rounded">
            🔒 Your API key is stored locally in your browser and never sent to our servers.
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}