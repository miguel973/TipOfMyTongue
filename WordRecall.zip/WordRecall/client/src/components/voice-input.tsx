import { Mic, MicOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useSpeechRecognition } from "@/hooks/use-speech-recognition";
import { useEffect } from "react";

interface VoiceInputProps {
  onTranscript: (text: string) => void;
  disabled?: boolean;
}

export function VoiceInput({ onTranscript, disabled = false }: VoiceInputProps) {
  const {
    isListening,
    transcript,
    isSupported,
    startListening,
    stopListening,
    resetTranscript,
    error
  } = useSpeechRecognition();

  useEffect(() => {
    if (transcript) {
      onTranscript(transcript);
      resetTranscript();
    }
  }, [transcript, onTranscript, resetTranscript]);

  const handleToggle = () => {
    if (isListening) {
      stopListening();
    } else {
      startListening();
    }
  };

  if (!isSupported) {
    return (
      <Button
        disabled
        size="icon"
        className="w-12 h-12 rounded-full bg-gray-300 cursor-not-allowed"
        title="Voice input not supported in this browser"
      >
        <MicOff className="h-5 w-5" />
      </Button>
    );
  }

  return (
    <Button
      onClick={handleToggle}
      disabled={disabled}
      size="icon"
      className={`w-12 h-12 rounded-full transition-all duration-150 ${
        isListening 
          ? "bg-red-500 hover:bg-red-600 animate-pulse" 
          : "bg-blue-500 hover:bg-blue-600"
      }`}
      title={isListening ? "Stop listening" : "Start voice input"}
    >
      {isListening ? (
        <MicOff className="h-5 w-5 text-white" />
      ) : (
        <Mic className="h-5 w-5 text-white" />
      )}
    </Button>
  );
}
