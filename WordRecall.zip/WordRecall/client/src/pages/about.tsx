import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, Cpu, Database, Globe, Zap, Shield, Code } from "lucide-react";
import { Link } from "wouter";

export default function About() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-white to-gray-50">
      {/* Header */}
      <header className="pt-8 pb-4">
        <div className="max-w-4xl mx-auto px-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 mb-2">Tip Of My Tongue</h1>
              <p className="text-gray-600">Technical Overview & Architecture</p>
            </div>
            <Link href="/">
              <Button variant="ghost" className="flex items-center gap-2">
                <ArrowLeft className="w-4 h-4" />
                Back to App
              </Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 py-8 space-y-8">
        {/* Overview */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Zap className="w-5 h-5 text-blue-500" />
              Project Overview
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-gray-700 leading-relaxed">
              Tip Of My Tongue is an AI-powered word suggestion application designed to help users quickly 
              find words they can't quite remember. Built with modern web technologies and multiple AI 
              provider integration, it delivers intelligent word suggestions in under 2 seconds.
            </p>
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <h4 className="font-semibold text-gray-900 mb-2">Key Features</h4>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• Text and voice input support</li>
                  <li>• Multi-provider AI integration</li>
                  <li>• User-controlled API keys</li>
                  <li>• Sub-2 second response times</li>
                  <li>• Contextual word suggestions</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold text-gray-900 mb-2">Technology Stack</h4>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• React + TypeScript frontend</li>
                  <li>• Express.js backend API</li>
                  <li>• OpenAI, Anthropic, Gemini APIs</li>
                  <li>• Tailwind CSS + shadcn/ui</li>
                  <li>• TanStack Query for state</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Technical Architecture */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Code className="w-5 h-5 text-green-500" />
              Technical Architecture
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <h4 className="font-semibold text-gray-900 mb-3">System Flow</h4>
              <div className="bg-gray-50 p-6 rounded-lg font-mono text-sm overflow-x-auto">
                <pre className="text-gray-700 leading-relaxed">
{`┌─────────────────┐       ┌──────────────────┐       ┌─────────────────┐
│   User Input    │       │   Frontend App   │       │  Backend API    │
│  Text/Voice     │──────▶│  React + TS      │──────▶│  Express.js     │
│  Description    │       │  - Input validation      │  - Route handler │
└─────────────────┘       │  - State management      │  - Provider      │
                          └──────────────────┘       │    selection     │
                                                     └─────────────────┘
                                                              │
                                                              ▼
┌─────────────────┐       ┌──────────────────┐       ┌─────────────────┐
│ Word Suggestions│       │  JSON Response   │       │   AI Provider   │
│   Display       │◀──────│   Processing     │◀──────│ OpenAI/Anthropic│
│ - Match %       │       │  - Parse JSON    │       │   /Google       │
│ - Definitions   │       │  - Validate      │       │ - GPT-4o        │
│ - Categories    │       │  - Format        │       │ - Claude 4.0    │
└─────────────────┘       └──────────────────┘       │ - Gemini 2.5    │
                                                     └─────────────────┘

Flow Details:
1. User enters description via text input or voice recognition
2. Frontend validates input and sends POST request to /api/search
3. Backend selects AI provider based on user settings or fallback
4. AI provider processes description with optimized prompts
5. JSON response parsed and validated against schema
6. Word suggestions displayed with match percentages and definitions`}
                </pre>
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                  <Globe className="w-4 h-4" />
                  Frontend Architecture
                </h4>
                <ul className="text-sm text-gray-600 space-y-2">
                  <li><strong>React 18:</strong> Component-based UI with hooks</li>
                  <li><strong>TypeScript:</strong> Type safety across components</li>
                  <li><strong>Vite:</strong> Fast development and build tool</li>
                  <li><strong>TanStack Query:</strong> Server state management</li>
                  <li><strong>Wouter:</strong> Lightweight client-side routing</li>
                  <li><strong>shadcn/ui:</strong> Accessible component library</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                  <Database className="w-4 h-4" />
                  Backend Architecture
                </h4>
                <ul className="text-sm text-gray-600 space-y-2">
                  <li><strong>Express.js:</strong> RESTful API server</li>
                  <li><strong>Zod:</strong> Request/response validation</li>
                  <li><strong>Multi-Provider:</strong> OpenAI, Anthropic, Gemini</li>
                  <li><strong>TypeScript:</strong> End-to-end type safety</li>
                  <li><strong>Error Handling:</strong> Graceful timeout management</li>
                  <li><strong>Rate Limiting:</strong> Built-in request timeout</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* AI Integration */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Cpu className="w-5 h-5 text-purple-500" />
              AI Integration & Processing
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h4 className="font-semibold text-gray-900 mb-3">How AI Processing Works</h4>
              <div className="space-y-3 text-sm text-gray-700">
                <div className="flex items-start gap-3">
                  <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded text-xs font-semibold">1</span>
                  <div>
                    <strong>Input Processing:</strong> User description is captured via text input or speech recognition API
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded text-xs font-semibold">2</span>
                  <div>
                    <strong>API Selection:</strong> System chooses between user's API key or fallback server key
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded text-xs font-semibold">3</span>
                  <div>
                    <strong>Prompt Engineering:</strong> Description is formatted into optimized prompt for AI model
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded text-xs font-semibold">4</span>
                  <div>
                    <strong>AI Processing:</strong> Request sent to chosen provider (OpenAI, Anthropic, or Gemini)
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded text-xs font-semibold">5</span>
                  <div>
                    <strong>Response Parsing:</strong> JSON response validated and structured word suggestions extracted
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded text-xs font-semibold">6</span>
                  <div>
                    <strong>Display:</strong> Word suggestions rendered with definitions, categories, and match percentages
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-blue-50 p-4 rounded-lg">
              <h5 className="font-semibold text-blue-900 mb-2">AI Provider Support</h5>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                <div>
                  <strong className="text-blue-800">OpenAI</strong>
                  <div className="text-blue-600">GPT-4o, GPT-4o-mini, GPT-3.5-turbo</div>
                </div>
                <div>
                  <strong className="text-blue-800">Anthropic</strong>
                  <div className="text-blue-600">Claude Sonnet 4.0, Claude 3.7</div>
                </div>
                <div>
                  <strong className="text-blue-800">Google</strong>
                  <div className="text-blue-600">Gemini 2.5 Flash, Gemini 2.5 Pro</div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Security & Privacy */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="w-5 h-5 text-red-500" />
              Security & Privacy
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold text-gray-900 mb-3">Data Protection</h4>
                <ul className="text-sm text-gray-600 space-y-2">
                  <li>• API keys stored locally in browser</li>
                  <li>• No sensitive data sent to application servers</li>
                  <li>• Search queries not permanently stored</li>
                  <li>• HTTPS encryption for all communications</li>
                  <li>• No user tracking or analytics collection</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold text-gray-900 mb-3">API Security</h4>
                <ul className="text-sm text-gray-600 space-y-2">
                  <li>• Request timeout protection (10 seconds)</li>
                  <li>• Input validation using Zod schemas</li>
                  <li>• Graceful error handling and fallbacks</li>
                  <li>• Provider-specific authentication</li>
                  <li>• Cost control through user-managed keys</li>
                </ul>
              </div>
            </div>
            
            <div className="bg-green-50 p-4 rounded-lg">
              <h5 className="font-semibold text-green-900 mb-2">Privacy by Design</h5>
              <p className="text-sm text-green-700">
                The application is designed with privacy as a core principle. User API keys never leave the browser, 
                search queries are not logged or stored permanently, and the system operates on a stateless architecture 
                that doesn't retain user data between sessions.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Performance */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Zap className="w-5 h-5 text-yellow-500" />
              Performance Optimizations
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold text-gray-900 mb-3">Frontend Optimizations</h4>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• Hot module replacement in development</li>
                  <li>• Optimized bundle splitting</li>
                  <li>• Lazy loading of components</li>
                  <li>• Efficient state management</li>
                  <li>• Debounced input handling</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold text-gray-900 mb-3">Backend Optimizations</h4>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• Optimized AI prompts for speed</li>
                  <li>• Concurrent request handling</li>
                  <li>• Efficient JSON parsing</li>
                  <li>• Request timeout management</li>
                  <li>• Error recovery mechanisms</li>
                </ul>
              </div>
            </div>
            
            <div className="bg-yellow-50 p-4 rounded-lg">
              <h5 className="font-semibold text-yellow-900 mb-2">Speed Targets</h5>
              <p className="text-sm text-yellow-700">
                The system is optimized to deliver word suggestions in under 2 seconds for most queries, 
                with typical response times between 750ms-1.5s depending on the AI provider and query complexity.
              </p>
            </div>
          </CardContent>
        </Card>
      </main>

      {/* Footer */}
      <footer className="max-w-4xl mx-auto px-4 py-8 border-t border-gray-100 mt-12">
        <div className="text-center text-sm text-gray-600">
          <p>Built with React, TypeScript, and modern AI technologies</p>
          <p className="mt-2">Designed for speed, privacy, and user control</p>
        </div>
      </footer>
    </div>
  );
}