import { useState, useRef, useEffect } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { VoiceInput } from "@/components/voice-input";
import { ApiSettings } from "@/components/api-settings";
import { Search, X, Copy, ExternalLink, Lightbulb, Tag, Star, Book, Search as SearchIcon } from "lucide-react";
import { Link } from "wouter";
import type { SearchResponse, WordSuggestion } from "@shared/schema";

interface ApiConfig {
  provider: string;
  model: string;
  apiKey: string;
}

function formatProcessingTime(timeMs: number): string {
  if (timeMs < 1000) {
    return `${timeMs}ms`;
  } else if (timeMs < 60000) {
    return `${(timeMs / 1000).toFixed(1)}s`;
  } else {
    const minutes = Math.floor(timeMs / 60000);
    const seconds = ((timeMs % 60000) / 1000).toFixed(1);
    return `${minutes}m ${seconds}s`;
  }
}

export default function Home() {
  const [inputText, setInputText] = useState("");
  const [suggestions, setSuggestions] = useState<WordSuggestion[]>([]);
  const [processingTime, setProcessingTime] = useState<number | null>(null);
  const [apiConfig, setApiConfig] = useState<ApiConfig>({ provider: '', model: '', apiKey: '' });
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const { toast } = useToast();

  const searchMutation = useMutation({
    mutationFn: async (description: string): Promise<SearchResponse> => {
      const payload = { description };
      
      // Add API config if user has provided their own key
      if (apiConfig.apiKey && apiConfig.provider && apiConfig.model) {
        Object.assign(payload, {
          provider: apiConfig.provider,
          model: apiConfig.model,
          apiKey: apiConfig.apiKey
        });
      }
      
      const response = await apiRequest("POST", "/api/search", payload);
      return response.json();
    },
    onSuccess: (data) => {
      setSuggestions(data.suggestions);
      setProcessingTime(data.processingTimeMs);
      if (data.suggestions.length === 0) {
        toast({
          title: "No matches found",
          description: "Try describing the word differently or with more detail.",
        });
      }
    },
    onError: (error: any) => {
      console.error("Search error:", error);
      setSuggestions([]);
      toast({
        title: "Search failed",
        description: error.message || "Unable to search at this time. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSearch = () => {
    if (!inputText.trim()) {
      toast({
        title: "Please enter a description",
        description: "Describe what you're trying to remember.",
        variant: "destructive",
      });
      return;
    }
    searchMutation.mutate(inputText.trim());
  };

  const handleClear = () => {
    setInputText("");
    setSuggestions([]);
    setProcessingTime(null);
    textareaRef.current?.focus();
  };

  const handleVoiceTranscript = (transcript: string) => {
    setInputText(prev => prev + transcript);
  };

  const copyToClipboard = async (word: string) => {
    try {
      await navigator.clipboard.writeText(word);
      toast({
        title: "Copied!",
        description: `"${word}" copied to clipboard`,
      });
    } catch (err) {
      toast({
        title: "Copy failed",
        description: "Unable to copy to clipboard",
        variant: "destructive",
      });
    }
  };

  const openGoogleSearch = (word: string) => {
    window.open(`https://www.google.com/search?q=${encodeURIComponent(word)}`, "_blank");
  };

  const openDictionary = (word: string) => {
    window.open(`https://www.merriam-webster.com/dictionary/${encodeURIComponent(word)}`, "_blank");
  };

  const openWikipedia = (word: string) => {
    window.open(`https://en.wikipedia.org/wiki/${encodeURIComponent(word)}`, "_blank");
  };

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.metaKey || e.ctrlKey) {
        switch (e.key) {
          case "k":
            e.preventDefault();
            handleClear();
            break;
          case "Enter":
            e.preventDefault();
            handleSearch();
            break;
          case "m":
            e.preventDefault();
            // Focus will trigger voice input component
            textareaRef.current?.focus();
            break;
        }
      }
    };

    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [inputText]);

  // Auto-focus on mount
  useEffect(() => {
    textareaRef.current?.focus();
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-white to-gray-50">
      {/* Header */}
      <header className="pt-8 pb-4">
        <div className="max-w-2xl mx-auto px-4">
          <div className="flex items-center justify-between">
            <div className="text-center flex-1">
              <h1 className="text-2xl font-semibold text-gray-900 mb-2">Tip Of My Tongue</h1>
              <p className="text-gray-600 text-sm">Remember words instantly</p>
            </div>
            <div className="ml-4 flex items-center gap-2">
              <Link href="/about">
                <Button variant="ghost" size="sm" className="text-gray-600 hover:text-gray-900">
                  About
                </Button>
              </Link>
              <ApiSettings onConfigChange={setApiConfig} />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-2xl mx-auto px-4 py-8">
        {/* Input Section */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 mb-8">
          <div className="relative">
            <Textarea
              ref={textareaRef}
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Describe what you're trying to remember... (e.g., 'that word for when you can't sleep because of overthinking')"
              className="min-h-32 text-base border-0 resize-none focus:outline-none focus:ring-0 placeholder-gray-500 bg-transparent"
              disabled={searchMutation.isPending}
            />
            
            {/* Voice Input Button */}
            <div className="absolute bottom-4 right-4">
              <VoiceInput 
                onTranscript={handleVoiceTranscript}
                disabled={searchMutation.isPending}
              />
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3 mt-4">
            <Button 
              onClick={handleSearch}
              disabled={searchMutation.isPending || !inputText.trim()}
              className="flex-1 bg-blue-500 text-white py-3 px-6 rounded-xl font-medium hover:bg-blue-600 transition-colors duration-150 ios-button"
            >
              <Search className="mr-2 h-4 w-4" />
              {searchMutation.isPending ? "Thinking..." : "Find Word"}
            </Button>
            <Button 
              onClick={handleClear}
              variant="ghost"
              className="px-4 py-3 text-gray-600 hover:text-gray-900 transition-colors duration-150 rounded-xl"
              title="Clear input (⌘K)"
            >
              <X className="h-5 w-5" />
            </Button>
          </div>

          {/* Loading State */}
          {searchMutation.isPending && (
            <div className="mt-4 flex items-center justify-center py-4">
              <div className="flex items-center gap-3">
                <div className="w-5 h-5 border-2 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
                <span className="text-gray-600">Thinking...</span>
              </div>
            </div>
          )}
        </div>

        {/* Results Section */}
        {suggestions.length > 0 && (
          <div className="space-y-4 fade-in">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold text-gray-900">Possible matches:</h2>
              {processingTime && (
                <span className="text-sm text-gray-500">
                  Found in {formatProcessingTime(processingTime)}
                </span>
              )}
            </div>
            
            {suggestions.map((suggestion, index) => (
              <div 
                key={index}
                className="bg-white rounded-xl shadow-sm border border-gray-100 p-5 suggestion-card"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <button 
                      className="text-left w-full group"
                      onClick={() => copyToClipboard(suggestion.word)}
                    >
                      <h3 className="text-xl font-semibold text-blue-500 group-hover:text-blue-600 mb-2">
                        {suggestion.word}
                      </h3>
                      <p className="text-gray-900 mb-3 leading-relaxed">
                        {suggestion.definition}
                      </p>
                      <div className="flex items-center gap-4 text-sm text-gray-600">
                        <span className="flex items-center gap-1">
                          <Tag className="w-3 h-3" />
                          {suggestion.category}
                        </span>
                        <span className="flex items-center gap-1">
                          <Star className="w-3 h-3" />
                          {suggestion.matchPercentage}% match
                        </span>
                      </div>
                    </button>
                  </div>
                  <div className="ml-4 flex gap-2">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => copyToClipboard(suggestion.word)}
                      className="p-2 text-gray-600 hover:text-blue-500 transition-colors duration-150 rounded-lg hover:bg-gray-50"
                      title="Copy word"
                    >
                      <Copy className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => openGoogleSearch(suggestion.word)}
                      className="p-2 text-gray-600 hover:text-blue-500 transition-colors duration-150 rounded-lg hover:bg-gray-50"
                      title="More information"
                    >
                      <ExternalLink className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}

            {/* Additional Resources */}
            <div className="mt-8 p-4 bg-gray-50 rounded-xl">
              <h3 className="font-medium text-gray-900 mb-3">Helpful resources:</h3>
              <div className="space-y-2">
                <button 
                  onClick={() => suggestions.length > 0 && openDictionary(suggestions[0].word)}
                  className="flex items-center gap-2 text-blue-500 hover:text-blue-600 text-sm w-full text-left"
                >
                  <Book className="w-3 h-3" />
                  Dictionary definition and etymology
                </button>
                <button 
                  onClick={() => suggestions.length > 0 && openWikipedia(suggestions[0].word)}
                  className="flex items-center gap-2 text-blue-500 hover:text-blue-600 text-sm w-full text-left"
                >
                  <ExternalLink className="w-3 h-3" />
                  Wikipedia article
                </button>
                <button 
                  onClick={() => suggestions.length > 0 && openGoogleSearch(suggestions[0].word)}
                  className="flex items-center gap-2 text-blue-500 hover:text-blue-600 text-sm w-full text-left"
                >
                  <SearchIcon className="w-3 h-3" />
                  Google search results
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Empty State */}
        {suggestions.length === 0 && !searchMutation.isPending && (
          <div className="text-center py-12">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Lightbulb className="w-8 h-8 text-gray-600" />
            </div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">Ready to help you remember</h3>
            <p className="text-gray-600 max-w-sm mx-auto">
              Describe what you're trying to remember and we'll find the word in under 1.27 seconds
            </p>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="max-w-2xl mx-auto px-4 py-8 border-t border-gray-100 mt-12">
        <div className="text-center text-sm text-gray-600 space-y-2">
          <div className="flex justify-center gap-6">
            <span><kbd className="px-2 py-1 bg-gray-100 rounded text-xs">⌘K</kbd> Clear</span>
            <span><kbd className="px-2 py-1 bg-gray-100 rounded text-xs">⌘Enter</kbd> Search</span>
            <span><kbd className="px-2 py-1 bg-gray-100 rounded text-xs">⌘M</kbd> Voice</span>
          </div>
          <p>Optimized for speed • Privacy-focused • No data stored</p>
        </div>
      </footer>
    </div>
  );
}
