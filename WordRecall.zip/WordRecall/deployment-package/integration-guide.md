# Integration Guide for Your Other Agent

## Overview
The Tip Of My Tongue app is ready for integration at `taverasholdings.com/tomt`. Here's everything your other agent needs to know:

## Built Files Location
- **Frontend**: `dist/public/` (HTML, CSS, JS assets)
- **Backend**: `dist/index.js` (Express server)
- **Size**: ~120KB gzipped total

## Integration Strategy

### Option A: Microservice (Recommended)
Deploy as a separate service behind reverse proxy:

1. **Backend Service**:
   ```bash
   # Deploy to a server/container
   node dist/index.js  # Runs on port 5000
   ```

2. **Nginx Configuration**:
   ```nginx
   location /tomt/ {
       proxy_pass http://localhost:5000/;
       proxy_set_header Host $host;
       proxy_set_header X-Real-IP $remote_addr;
       proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
       proxy_set_header X-Forwarded-Proto $scheme;
   }
   ```

### Option B: Static + API Proxy
1. Copy `dist/public/*` to `/tomt/` on web server
2. Proxy `/tomt/api/*` to backend service

## Required Environment Variables
```bash
OPENAI_API_KEY=sk-...  # Your OpenAI key for fallback
NODE_ENV=production
```

## API Endpoints
- `POST /api/search` - Main functionality
- Expects: `{"description": "string", "maxResults": number}`
- Returns: `{"suggestions": [...], "processingTimeMs": number}`

## Dependencies to Install
```bash
npm install express @anthropic-ai/sdk @google/genai openai zod
```

## Key Features
- ⚡ 750ms-1.5s response times
- 🔒 User API keys stored in browser (not server)
- 🗣️ Voice input via Web Speech API
- 🤖 Multi-provider AI (OpenAI, Anthropic, Gemini)
- 📱 Mobile responsive

## File Structure for Integration
```
your-website/
├── tomt/                 # Frontend assets
│   ├── index.html
│   ├── assets/
│   │   ├── index-*.js
│   │   └── index-*.css
└── backend-services/
    └── tomt-api/         # Backend service
        ├── dist/index.js
        └── package.json
```

## Testing Checklist
1. ✅ `/tomt/` loads main interface
2. ✅ Word search works (try "word for unable to sleep")
3. ✅ Voice input functions (browser permission required)
4. ✅ API settings dialog opens
5. ✅ Response times under 2 seconds

## Security Notes
- No sensitive data stored server-side
- API keys managed by users in localStorage
- Request timeouts prevent runaway costs
- CORS configured for production

## Performance Optimizations
- Gzipped assets (~120KB total)
- Optimized AI prompts for speed
- Efficient React bundle splitting
- CDN-ready static assets

## Domain Configuration
Once deployed, the app will be available at:
- `https://taverasholdings.com/tomt/`

Users can bookmark it and access directly. The app is fully self-contained within that path.