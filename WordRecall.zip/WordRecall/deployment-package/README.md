# Tip Of My Tongue - Integration Package

## Quick Start for taverasholdings.com/tomt

This package contains everything needed to integrate the Tip Of My Tongue app into your main website.

## What's Included
- ✅ Built frontend assets (HTML, CSS, JS)
- ✅ Backend server code
- ✅ Configuration files
- ✅ Integration instructions
- ✅ Environment setup guide

## Recommended Integration Path: `/tomt`

### Step 1: Copy Files
1. Copy `dist/public/*` to your web server directory for `/tomt/`
2. Deploy the backend service (Node.js) separately

### Step 2: Configure Reverse Proxy
Add this to your web server config (Nginx example):
```nginx
location /tomt/ {
    proxy_pass http://localhost:5000/;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
}
```

### Step 3: Environment Variables
Set these in your backend environment:
```
OPENAI_API_KEY=your_key_here
NODE_ENV=production
```

### Step 4: Start Backend Service
```bash
cd tip-of-my-tongue-backend
npm install
node dist/index.js
```

## Features Ready for Production
- ⚡ Sub-2 second response times
- 🔒 Secure API key management
- 🗣️ Voice input support
- 🤖 Multi-AI provider support (OpenAI, Anthropic, Gemini)
- 📱 Mobile-responsive design
- 🎯 Optimized for conversational word recall

## Technical Details
- **Frontend**: React SPA with TypeScript
- **Backend**: Express.js API server
- **AI Integration**: OpenAI GPT-4o, Anthropic Claude, Google Gemini
- **Bundle Size**: ~344KB JS, ~62KB CSS (gzipped: ~120KB total)
- **Performance**: Optimized for fast loading and AI response times

## Support & Maintenance
- Self-contained application with minimal dependencies
- User-controlled API costs through personal keys
- Fallback server key for demo functionality
- No database required for core functionality