import { type WordSuggestion, type SearchRequest, type SearchResponse } from "@shared/schema";

// This app doesn't need persistent storage as it's a search utility
// The IStorage interface is kept minimal for potential future features

export interface IStorage {
  // Placeholder for potential future features like search history
  logSearch(description: string, resultCount: number): Promise<void>;
}

export class MemStorage implements IStorage {
  private searchLogs: Array<{ description: string; resultCount: number; timestamp: Date }> = [];

  async logSearch(description: string, resultCount: number): Promise<void> {
    // Optional: Log searches for analytics (keeping last 100)
    this.searchLogs.push({
      description,
      resultCount,
      timestamp: new Date()
    });
    
    if (this.searchLogs.length > 100) {
      this.searchLogs.shift();
    }
  }
}

export const storage = new MemStorage();
