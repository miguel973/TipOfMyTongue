import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { findWordSuggestions, findWordSuggestionsWithProvider } from "./services/ai-providers";
import { searchRequestSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Health check endpoint
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", timestamp: new Date().toISOString() });
  });

  // Main search endpoint for word suggestions
  app.post("/api/search", async (req, res) => {
    try {
      const startTime = Date.now();
      
      // Validate request body
      const validationResult = searchRequestSchema.safeParse(req.body);
      if (!validationResult.success) {
        return res.status(400).json({
          error: "Invalid request",
          details: validationResult.error.errors
        });
      }

      const { description, maxResults = 5, provider, model, apiKey } = validationResult.data;

      // Set a reasonable timeout for AI API calls
      const TIMEOUT_MS = 10000; // 10 seconds for external API calls
      
      const timeoutPromise = new Promise((_, reject) => {
        setTimeout(() => reject(new Error("Request timeout")), TIMEOUT_MS);
      });

      // Choose between user's API key or server's default
      const searchPromise = (provider && model && apiKey) 
        ? findWordSuggestionsWithProvider(description, provider, model, apiKey)
        : findWordSuggestions(description);

      try {
        const result = await Promise.race([searchPromise, timeoutPromise]) as {
          suggestions: any[];
          processingTimeMs: number;
        };
        const totalTime = Date.now() - startTime;

        // Log the search
        await storage.logSearch(description, result.suggestions.length);

        // Limit results to maxResults
        const limitedSuggestions = result.suggestions.slice(0, maxResults);

        const response = {
          suggestions: limitedSuggestions,
          processingTimeMs: totalTime,
          hasMore: result.suggestions.length > maxResults
        };

        res.json(response);
      } catch (timeoutError) {
        const totalTime = Date.now() - startTime;
        
        res.status(408).json({
          error: "Search timeout",
          message: "Request took too long. Please try a shorter description.",
          processingTimeMs: totalTime
        });
      }

    } catch (error) {
      console.error("Search endpoint error:", error);
      res.status(500).json({
        error: "Internal server error",
        message: "Unable to process search request"
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
