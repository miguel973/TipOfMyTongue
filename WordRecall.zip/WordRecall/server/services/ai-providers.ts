import OpenAI from "openai";
import Anthropic from '@anthropic-ai/sdk';
import { GoogleGenAI } from "@google/genai";

interface WordSuggestion {
  word: string;
  definition: string;
  category: string;
  matchPercentage: number;
  etymology?: string;
  examples?: string[];
}

interface AiResponse {
  suggestions: WordSuggestion[];
  processingTimeMs: number;
}

const createPrompt = (description: string) => {
  return `Find the word from this description: "${description}"

Return JSON:
{
  "suggestions": [
    {
      "word": "word",
      "definition": "definition",
      "category": "category",
      "matchPercentage": 85
    }
  ]
}

Max 3 words, high confidence only.`;
};

export async function findWordSuggestionsWithProvider(
  description: string,
  provider: string,
  model: string,
  apiKey: string
): Promise<AiResponse> {
  const startTime = Date.now();

  try {
    let content: string;

    switch (provider) {
      case 'openai':
        content = await callOpenAI(description, model, apiKey);
        break;
      case 'anthropic':
        content = await callAnthropic(description, model, apiKey);
        break;
      case 'gemini':
        content = await callGemini(description, model, apiKey);
        break;
      default:
        throw new Error(`Unsupported provider: ${provider}`);
    }

    const processingTimeMs = Date.now() - startTime;
    
    try {
      const result = JSON.parse(content);
      return {
        suggestions: result.suggestions || [],
        processingTimeMs
      };
    } catch (parseError) {
      console.error("JSON parsing error:", parseError);
      console.error("Raw content:", content);
      return {
        suggestions: [],
        processingTimeMs
      };
    }
  } catch (error) {
    const processingTimeMs = Date.now() - startTime;
    console.error(`${provider} API error:`, error);
    
    return {
      suggestions: [],
      processingTimeMs
    };
  }
}

async function callOpenAI(description: string, model: string, apiKey: string): Promise<string> {
  const openai = new OpenAI({ apiKey });
  
  const response = await openai.chat.completions.create({
    model,
    messages: [
      {
        role: "user",
        content: createPrompt(description)
      }
    ],
    response_format: { type: "json_object" },
    max_tokens: 400,
    temperature: 0
  });

  return response.choices[0].message.content || "{}";
}

async function callAnthropic(description: string, model: string, apiKey: string): Promise<string> {
  const anthropic = new Anthropic({ apiKey });
  
  const response = await anthropic.messages.create({
    model,
    max_tokens: 400,
    system: "You are a helpful assistant that helps people remember words. Respond only with valid JSON.",
    messages: [
      {
        role: 'user',
        content: createPrompt(description)
      }
    ],
  });

  return response.content[0].type === 'text' ? response.content[0].text : "{}";
}

async function callGemini(description: string, model: string, apiKey: string): Promise<string> {
  const ai = new GoogleGenAI({ apiKey });
  
  const response = await ai.models.generateContent({
    model,
    config: {
      responseMimeType: "application/json",
    },
    contents: createPrompt(description),
  });

  return response.text || "{}";
}

// Legacy function for backward compatibility (uses environment OpenAI key)
export async function findWordSuggestions(description: string): Promise<AiResponse> {
  const apiKey = process.env.OPENAI_API_KEY || "";
  if (!apiKey) {
    throw new Error("No API key available");
  }
  
  return findWordSuggestionsWithProvider(description, 'openai', 'gpt-3.5-turbo', apiKey);
}