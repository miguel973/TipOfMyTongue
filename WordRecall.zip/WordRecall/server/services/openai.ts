import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || ""
});

interface WordSuggestion {
  word: string;
  definition: string;
  category: string;
  matchPercentage: number;
  etymology?: string;
  examples?: string[];
}

export async function findWordSuggestions(description: string): Promise<{
  suggestions: WordSuggestion[];
  processingTimeMs: number;
}> {
  const startTime = Date.now();
  
  try {
    const prompt = `Find the word from this description: "${description}"

Return JSON:
{
  "suggestions": [
    {
      "word": "word",
      "definition": "definition",
      "category": "category",
      "matchPercentage": 85
    }
  ]
}

Max 3 words, high confidence only.`;

    const response = await openai.chat.completions.create({
      model: "gpt-3.5-turbo", // Using fastest available model
      messages: [
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      max_tokens: 400,
      temperature: 0
    });

    const content = response.choices[0].message.content || "{}";
    const processingTimeMs = Date.now() - startTime;
    
    try {
      const result = JSON.parse(content);
      return {
        suggestions: result.suggestions || [],
        processingTimeMs
      };
    } catch (parseError) {
      console.error("JSON parsing error:", parseError);
      console.error("Raw content:", content);
      return {
        suggestions: [],
        processingTimeMs
      };
    }
  } catch (error) {
    const processingTimeMs = Date.now() - startTime;
    console.error("OpenAI API error:", error);
    
    // Fallback response for API failures
    return {
      suggestions: [],
      processingTimeMs
    };
  }
}
